import scala.math.Ordering

sealed trait Tree[+A]

case class Leaf[A](value: A) extends Tree[A]

case class Branch[A](left: Tree[A], right: Tree[A]) extends Tree[A]

class BinaryTree[A] {
  def search(tree: Tree[A], target: A)(implicit ordering: Ordering[A]): Boolean = tree match {
    case Leaf(value) => value == target
    case Branch(left, right) => search(left, target) || search(right, target)
  }

  def isLeaf(tree: Tree[A]): Boolean = tree match {
    case Leaf(_) => true
    case _ => false
  }

  def maximum(tree: Tree[A])(implicit ordering: Ordering[A]): A = tree match {
    case Leaf(value) => value
    case Branch(left, right) => ordering.max(maximum(left), maximum(right))
  }

  def minimum(tree: Tree[A])(implicit ordering: Ordering[A]): A = tree match {
    case Leaf(value) => value
    case Branch(left, right) => ordering.min(minimum(left), minimum(right))
  }

  def depth(tree: Tree[A]): Int = tree match {
    case Leaf(_) => 1
    case Branch(left, right) => 1 + depth(left).max(depth(right))
  }

  def map(tree: Tree[A])(f: A => A): Tree[A] = tree match {
    case Leaf(value) => Leaf(f(value))
    case Branch(left, right) => Branch(map(left)(f), map(right)(f))
  }

  def flatMap(tree: Tree[A])(f: A => Tree[A]): Tree[A] = tree match {
    case Leaf(value) => f(value)
    case Branch(left, right) => Branch(flatMap(left)(f), flatMap(right)(f))
  }

  def foldLeft[B](tree: Tree[A], z: B)(f: (B, A) => B): B = tree match {
    case Leaf(value) => f(z, value)
    case Branch(left, right) => foldLeft(right, foldLeft(left, z)(f))(f)
  }

  def foldRight[B](tree: Tree[A], z: B)(f: (A, B) => B): B = tree match {
    case Leaf(value) => f(value, z)
    case Branch(left, right) => foldRight(left, foldRight(right, z)(f))(f)
  }
}

