object Main extends App {
  val tree = Branch(Leaf(1), Branch(Leaf(2), Leaf(7)))
  val binaryTree = new BinaryTree[Int]

  println(binaryTree.search(tree, 3))
  println(binaryTree.isLeaf(tree))
  println(binaryTree.maximum(tree))
  println(binaryTree.minimum(tree));
  println(binaryTree.depth(tree))
  println(binaryTree.map(tree)(_ * 2))
  println(binaryTree.flatMap(tree)(i => Branch(Leaf(i), Leaf(i))))
  println(binaryTree.foldLeft(tree, 0)(_ + _))
  println(binaryTree.foldRight(tree, 0)(_ + _))
}